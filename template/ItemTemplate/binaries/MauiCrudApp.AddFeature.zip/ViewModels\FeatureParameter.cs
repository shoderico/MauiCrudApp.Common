﻿namespace $rootnamespace$.ViewModels;

public class $fileinputname$Parameter
{
}
