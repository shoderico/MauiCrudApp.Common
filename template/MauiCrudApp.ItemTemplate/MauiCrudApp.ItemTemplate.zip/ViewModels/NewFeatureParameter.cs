﻿namespace $rootnamespace$.$fileinputname$.ViewModels;

public class $fileinputname$Parameter
{
}
