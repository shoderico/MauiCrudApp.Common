using MauiCrudApp.Common.Views;
using $safeprojectname$.Features.ItemListEdit.ViewModels;

namespace $safeprojectname$.Features.ItemListEdit.Views;

public partial class ItemListPage : PageBase
{
    public ItemListPage(ItemListViewModel viewModel) : base(viewModel)
	{
        InitializeComponent();
        BindingContext = viewModel;
    }
}