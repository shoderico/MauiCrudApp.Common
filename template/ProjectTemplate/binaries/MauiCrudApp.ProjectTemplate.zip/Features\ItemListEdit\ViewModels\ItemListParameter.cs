namespace $safeprojectname$.Features.ItemListEdit.ViewModels;

public class ItemListParameter
{
    public string? SearchText { get; set; }
}
