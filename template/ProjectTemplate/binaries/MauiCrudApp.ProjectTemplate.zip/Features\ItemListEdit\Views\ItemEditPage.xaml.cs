using MauiCrudApp.Common.Views;
using $safeprojectname$.Features.ItemListEdit.ViewModels;

namespace $safeprojectname$.Features.ItemListEdit.Views;

public partial class ItemEditPage : PageBase
{
    public ItemEditPage(ItemEditViewModel viewModel) : base(viewModel)
	{
        InitializeComponent();
        BindingContext = viewModel;
    }
}