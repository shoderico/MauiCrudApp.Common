﻿namespace $safeprojectname$.Features.ItemList.ViewModels;

public class ItemListParameter
{
    public string? SearchText { get; set; }
}
